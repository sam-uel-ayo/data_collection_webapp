-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 12, 2024 at 08:47 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `student_bio`
--

-- --------------------------------------------------------

--
-- Table structure for table `login_details`
--

CREATE TABLE `login_details` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `Password` varchar(1000) NOT NULL,
  `Created at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `login_details`
--

INSERT INTO `login_details` (`id`, `username`, `Password`, `Created at`) VALUES
(1, 'michealade', '$2y$12$K.Rh4if20lXuOXn5TmeHcO3G33VUZZ1wSSebwiDsIb0megufhWPQa', '2024-02-12 08:40:12');

-- --------------------------------------------------------

--
-- Table structure for table `parent_data`
--

CREATE TABLE `parent_data` (
  `id` int(11) NOT NULL,
  `ParentSurname` varchar(255) NOT NULL,
  `ParentFirstName` varchar(255) NOT NULL,
  `OtherName` varchar(255) NOT NULL,
  `ParentPhoneNumber` varchar(255) NOT NULL,
  `EmailAddress` varchar(500) NOT NULL,
  `Address` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `parent_data`
--

INSERT INTO `parent_data` (`id`, `ParentSurname`, `ParentFirstName`, `OtherName`, `ParentPhoneNumber`, `EmailAddress`, `Address`) VALUES
(1, 'Adeyanju', 'Taiwo', 'James', '2349070343171', 'deyanjutaiwo@gmail.com', 'Lagos Nigeria');

-- --------------------------------------------------------

--
-- Table structure for table `student_data`
--

CREATE TABLE `student_data` (
  `id` int(11) NOT NULL,
  `MatricNumber` varchar(255) NOT NULL,
  `FirstName` varchar(255) NOT NULL,
  `Surname` varchar(255) NOT NULL,
  `DateOfBirth` date NOT NULL,
  `Nationality` varchar(255) NOT NULL,
  `Religion` varchar(255) NOT NULL,
  `PhoneNumber` varchar(255) NOT NULL,
  `Email` varchar(500) NOT NULL,
  `Department` text NOT NULL,
  `CurrentLevel` int(4) NOT NULL,
  `YearofEntry` year(4) NOT NULL,
  `ModeofEntry` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `student_data`
--

INSERT INTO `student_data` (`id`, `MatricNumber`, `FirstName`, `Surname`, `DateOfBirth`, `Nationality`, `Religion`, `PhoneNumber`, `Email`, `Department`, `CurrentLevel`, `YearofEntry`, `ModeofEntry`) VALUES
(1, '19N02015', 'Micheal', 'Adeanju', '2003-06-14', 'Nigerian', 'Christian', '2347055632123', 'michealade@gmail.com', 'Computer Science', 300, '2021', 'UTME');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `login_details`
--
ALTER TABLE `login_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `parent_data`
--
ALTER TABLE `parent_data`
  ADD KEY `id` (`id`);

--
-- Indexes for table `student_data`
--
ALTER TABLE `student_data`
  ADD UNIQUE KEY `Matric Number` (`MatricNumber`),
  ADD KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `login_details`
--
ALTER TABLE `login_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `parent_data`
--
ALTER TABLE `parent_data`
  ADD CONSTRAINT `parent_data_ibfk_1` FOREIGN KEY (`id`) REFERENCES `student_data` (`id`);

--
-- Constraints for table `student_data`
--
ALTER TABLE `student_data`
  ADD CONSTRAINT `student_data_ibfk_1` FOREIGN KEY (`id`) REFERENCES `login_details` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
